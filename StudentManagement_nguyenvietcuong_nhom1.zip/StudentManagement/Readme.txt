C�c buoc chay project:
1. m? file StudentManagement.sln voi visual studio
2. nh?n f5 de chay IIS Server
3. xem chi tiet API g� /help. vd: Localhost::<port>/help